Matej Čušin, IT admin @ OŠ Toneta Čufarja Jesenice. Docker Hub: mato12345/sola-app:latest. GitHub: os-tc-jesenice/reservation_app. k3s. SI primary, detail-obsessed, privacy-first. Multi-agent repo.
§
SI language. App updates instant: build→push→rollout per turn. Pre-build tests pre-deploy (PDF quality, broken buttons, git conflict markers). PDFs weasyprint, ne fpdf2. Docs: SI slovnica + EN prevodi. Čista login stran (samo učitelj). Testi na Firefox.
§
Upravlja šolsko rezervacijsko aplikacijo (OŠ Toneta Čufarja) v slovenščini; dela na dokumentaciji in feature-jih. Občutljiv na prave IP-je/gesla v dokumentaciji — {{VAR}} placeholders.
§
Production namespace: sola-app.
§
Node ukaze požene navadno na OBEH k3s nodih → agent naj jasno označi 'samo na X'.
§
Date format for school data (dnevi dejavnosti): vedno dd. mm. yyyy; obsegi "dd. mm. yyyy - dd. mm. yyyy"; razredi za datumom v oklepaju, ločeni z vejico (npr. 14. 9. 2026 - 16. 9. 2026 (2. a, 2. b)).
§
V istem Discord pogovoru deluje več Hermes agentov (k3s-1, k3s-2, Windows); ko user napiše "odgovarjaj samo X agent", sme odgovoriti izključno imenovani agent, drugi molčijo.