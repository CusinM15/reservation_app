sola-app (ostc-app.org): FastAPI on k8s namespace sola-app, image mato12345/sola-app:latest, PostgreSQL v18 CNPG, port 8002, MetalLB LB IP. HA: Cloudflare → LB IP → pod (no nginx). CNPG cluster sola-db živi v namespace `sola` (ne sola-app); app creds v secret sola-app/sola-secrets (DATABASE_URL postgresql://sola:***@sola-db-rw.sola:5432/sola); superuser `postgres` dosegljiv prek kubectl exec -n sola sola-db-1 (peer auth na local socketu).
§
Deployment: git push ≠ deployed; nato na k3s-2: docker build && docker push mato12345/sola-app:latest && kubectl rollout restart -n sola-app deployment/sola-app.
§
User docs style: senior-level quality, NO "seniorja" labels. Use "Nasvet:" not "Nasvet seniorja". English terms in SI docs must be translated. Explain ELI5 itself (user didn't know it). Draw.io files MUST use `&#xa;` not `<br>` in XML values or diagrams.net rejects them. Commit PNG alongside .drawio for GitHub rendering.
§
OSTC App: minimalni ciljani fixi v slovenščini. Detajli: skill ostc-app-development.
§
Rep: git pull --rebase pred delom; push samo ko user reče ("pukkaj").
§
Navodila: gumba Učitelji+Vodstvo (NE dropdown); PDF weasyprint; vodstvo+admin ena datoteka; git→app auto-update.
§
Windows PC 193.2.171.229: SSH22+AnyDesk7070; ni SSH gesla; codex CLI ni na k3s-1 → delegacija ni izvedljiva.
§
ostc-app testi: SAMO PostgreSQL (ne prod, ne tests/, ne CI). Detajli: skill ostc-app-development.
§
Hermes kvirk: *PASSWORD*/*AUTH*/DATABASE_URL= redaktirano v *** v terminalu; write_file ne. Workaround: trust URL/brez gesla ali write_file skript.
§
Čiščenje testnih podatkov: TRUNCATE (scripts/clean_test_data.sh -y), NE DROP.
§
k3s (3 nodi; SSH admin_os brez gesla, sudo ZAHTEVA geslo → sudo ukaze daš uporabniku; k3s restart ~30-60s API izpad). DNSConfigForming fix: resolv.conf+config.yaml. Dodajanje noda: skill ref adding-node-pitfalls.
§
Dnevi dejavnosti: xlsx ~/reservation_app/dnevi_dejavnosti_v_evrih.xlsx (X=prostor); skripte ~/dnevi_dejavnosti_2026-27/. ⚠️ App ure: hour=0=PREDURA(07:30), 1. ura=08:20=key"1"; "1.-5.ura"=hours[1,2,3,4,5] NE [0-4].
§
K3s/cluster operacije: user jih izvede SAM (agent: razlaga+komande, NE izvaja; read-only SSH diagnostika OK).